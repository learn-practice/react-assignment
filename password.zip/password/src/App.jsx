
import './App.css'
import Password from './component/Password'

function App() {
     return(
      <>
      <Password/>
      </>
     )
  
}

export default App
